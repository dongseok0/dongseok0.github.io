/**
 * Convert FORM html -> div element that is appendable into Board container.
 * 
 * @requires jQuery, URI.js (http://medialize.github.io/URI.js)
 * @author dongseok83.paeng@lge.com
 * @version 0.0.2
 */

(function($, URI, StringReplacer) {
	"use strict";
	function FormConverter() {
		this.options = {
			updateIfExistID : true
		};
	}

	var fn = FormConverter.prototype;

	fn.convertList = function(urlList) {
		var $deferred = $.Deferred();
		var defers = urlList.map(this.convert.bind(this));
		
		$.when.apply(null, defers).done(function() {
			$deferred.resolve(Array.prototype.slice.apply(arguments).map(function(i) {
				return { elem: i[0], type: i[1], param: i[2] };
			}));
		});
		
		return $deferred.promise();
	};

	// default options
	// updateIfExistID : true ( support for 1 uri )
	fn.convert = function(src, options) {
		options = (options || this.options);

		if( Array.isArray(src) ) {
			return this.convertList(src);
		}

		var deferred = $.Deferred();
		var uri = URI(src);
		var parsed = {
			'absoluteDirectory' : uri.protocol() + "://" +uri.directory() + "/",
			'absolutePath' : uri.protocol() + "://" + uri.path(),
			'queryKey' : uri.search(true)
		};

		if( options.updateIfExistID ) {
			var existElem = $('#'+parsed.queryKey.id);
			console.log(existElem);
			if( existElem.length > 0 ) {
				console.time("updating card");
				this.update(parsed, existElem).done(function() {
					console.timeEnd("updating card");

					// will be deprecated
					existElem.data("parameters", parsed.queryKey);

					deferred.resolve(existElem, "updateCard", parsed.queryKey);
				});
				return deferred.promise();
			}
		}

		// load form.html 
		$.ajax({
			url: parsed.absolutePath,
			dataType: 'text'
		}).then(

			// convert Param/String 
			function(data) {
				// support other path resources
				var resourceUri = parsed.queryKey.resourceUri || parsed.absoluteDirectory;
				return StringReplacer.convert(resourceUri, parsed.queryKey, data);
			}

		).then(

			// convert CSS relative path to absolute path ( link / style tags )
			function(data) {
				var $elem = $(data);
				this.convertStyleTags($elem, parsed.absoluteDirectory);
				return this.convertLinkTags($elem, parsed.absoluteDirectory);
			}.bind(this)

		).then(
		
			// convert ID ( css encapsulation )
			function($elem) {
				if( !parsed.queryKey.id ) {
					console.log("Card uri doesn't have ID. Skip css encapsulation.");
				} else {
					this.convertID($elem, parsed.queryKey.id);	
				}
				
				// will be deprecated
				$elem.data("parameters", parsed.queryKey);

				deferred.resolve($elem, "newCard", parsed.queryKey);
			}.bind(this)

		);

		return deferred.promise();
	};

	// convert ID for div and css
	fn.convertID = function($elem, uuid) {
		var id = $elem.attr('id');
		$elem.find('style').each(function() {
			var css = $(this).text();
			css = css.replace(new RegExp('#'+id, "g"), '#'+uuid);
			$(this).text(css);
		});

		$elem.attr('id', uuid);
	};

	// convert style tag
	fn.convertStyleTags = function($elem, baseDir) {
		var styleTags = $elem.find('style');
		var _this = this;
		styleTags.each(function() {
			var css = $(this).text();
			css = _this.rel2abs(css, baseDir);
			$(this).text(css);
		});
	};

	// convert link tags
	fn.convertLinkTags = function($elem, baseDir) {
		var deferred = $.Deferred();
		var styleText='';
		var linkTags = $elem.find('link[rel="stylesheet"]');
		var convert = 0;
		var _this = this;

		if(linkTags.length === 0) {
			return deferred.resolve($elem);
		}

		linkTags.each(function() {
			var $this = $(this);
			var media = $this.attr('media');
			var cssUri = baseDir + $this.attr('href');
			console.log("converting : " + cssUri);
			$.get(cssUri, function(data) {
				data = _this.rel2abs(data, URI(cssUri).directory()+"/");

				if( media !== undefined ) {
					data = '@media '+media+' {\n' + data + '\n}';
				}

				styleText += data;

			}).fail(function() {
				console.log(cssUri + " loading failed");
			}).always(function() {
				if(linkTags.length === ++convert) {
					linkTags.remove();
					$elem.append('<style>'+styleText+'</style>');
					deferred.resolve($elem);
				}
			});
		});
		return deferred.promise();
	};

	// convert relative path to absolute path : uri() format
	fn.rel2abs = function(data, baseDir) {
		return data.replace(/url\((['"]?)(.*)\1\)/g, function(match, p1, p2) {
			if( p2.indexOf("android.resource") === 0 ) {
				return match;
			} else if( URI(p2).protocol().length === 0 ) {
				var absPath = "url("+baseDir+p2+")";
				console.log(match + " -> " + absPath);
				return absPath;
			}
			return match;
		});
	};

	fn.update = function(parsed, elem) {
		var resourceUri = parsed.queryKey.resourceUri || parsed.absoluteDirectory;
		elem = elem || $('#'+parsed.queryKey.id);

		return StringReplacer.convert(resourceUri, parsed.queryKey, elem);
	};
	//FormConverter.update("file:///android_asset/www/helpform.html?title=title&subtitle=subtitile&description=desc&detail1=detail1&detail2=detail2")
	window.FormConverter = new FormConverter();

})(jQuery, URI.noConflict(), StringReplacer);