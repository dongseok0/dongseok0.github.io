(function() {
	"use strict";
	if( !window.JavaInterface ) {
		window.JavaInterface = {
			getResource : function(uri) {
				return uri;
			},

			getDeviceLocale : function() {
				return "en";
			},

			exportHTML : function(content) {
				console.log(content);
			},

			getDeviceFontScale: function() {
				return 1;
			},

			getLayoutDirection: function() {
				return 'ltr';
			}
		};
	}
})();