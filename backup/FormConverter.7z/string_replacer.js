(function($) {
	"use strict";
	function StringReplacer() {
	}

	var fn = StringReplacer.prototype;

	fn.parseStringResource = function(rawData) {
		var result = {};
		var strings = $(rawData).filter('resources').find('string');

		function replacer(match, slash, quote) {
			return slash ? quote : '';
		}
		function uniRep(match, code) {
			return String.fromCharCode(parseInt(code, 16));
		}

		strings.each(function(i, string) {
			result[string.getAttribute('name')] = string.innerHTML
				.replace(/\\n/g, '<br>')    // convert \n -> <br>
				.replace(/\\'/g, '\'')		// convert \' -> '
				//.replace(/^"/, '')
				.replace(/(\\){0,1}(")/g, replacer)
				.replace(/\\u([\d\w]{4})/gi, uniRep);
				//.replace(/\\"/g, '"');
		});

		return result;
	};

	fn.getStringPath = function() {
		// build pathArr such as [values, values-en, values-en-rAU]		
		var lang = window.JavaInterface.getDeviceLocale().split('_');
		return [
			"res/values/strings.xml",
			"res/values-" + lang[0] + "/strings.xml",
			"res/values-" + lang[0] + "-r" + lang[1] + "/strings.xml"
		];
	};

	fn.loadStringMap = function(baseDir) {
		var $deferred = $.Deferred();

		// Load strings sequecially and extend
		var strings = [],
			pathArr = this.getStringPath(baseDir),
			remains = pathArr.length;

		pathArr.forEach(function(path, index) {
			$.ajax({
				url: baseDir+path,
				dataType: 'text',
				context: this,
			}).done(function(data) {
				strings[index] = this.parseStringResource(data);
			}).fail(function() {
				console.log('failed to load : '+ path);
			}).always(function() {
				if( !(--remains) ) {
					$deferred.resolve( $.extend.apply(null, strings) );	
				}
			});	
		}, this);

		return $deferred.promise();
	};

	fn.replace = function(data, map) {
		return data.replace(/\[@(string|param)\/([^\[\]@]+)(?:\[@args\/(.+)\]){0,1}\]/g, function(match, $type, $id, $args) {
			var result = match;
			if( map[$type][$id] ) {
				result = this.replace(map[$type][$id], map);
			} else if( $type === 'string' ) {
				if( $id.indexOf('android.resource://') === 0) {
					result = window.JavaInterface.getResource($id);
				}
			}

			if( $args ) {

				var args = $args.match(/\[@(string|param)\/([^\[\]@]+)\]/g).map(function(arg) {
					return this.replace(arg, map);
				}.bind(this));
				console.log(args);

				result = vsprintf(result, args);
			}

			return result;

		}.bind(this));

/*		if( data.indexOf('android.resource://') === 0)
			return window.JavaInterface.getResource(data);
		else
			return data;*/
	};

	fn.replaceFromElement = function(data, map) {
		/*jshint forin:false*/
		for(var key in map.param) {
			if( key === 'id' || key === 'resourceUri') {
				continue;
			}
			
			var replacement = this.replace(map.param[key], map);
			//console.log('#'+parsed.queryKey.id+' [parameter="'+key+'"]');
			//console.log(data.find('[parameter-id="'+key+'"]'));

			//data.find('[parameter-id="'+key+'"]')[0].textContent = replacement;
			data.find('[parameter-id="'+key+'"]').html(replacement);
		}
	};

	fn.convert = function(baseDir, params, data) {
		var $deferred = $.Deferred();
		this.loadStringMap(baseDir).done(function(string) {
			var map = {
				'param' : params,
				'string' : string
			};

			if(typeof data === "string") {
				$deferred.resolve(this.replace(data, map));	
			} else {
				$deferred.resolve(this.replaceFromElement(data, map));
			}
			
		}.bind(this));

		return $deferred.promise();
	};
	
	window.StringReplacer = new StringReplacer();
	
})(jQuery);