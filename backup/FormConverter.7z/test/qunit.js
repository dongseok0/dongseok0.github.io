function waitFor(testFx, onReady, timeOutMillis) {                                                
    var maxtimeOutMillis = timeOutMillis ? timeOutMillis : 30001, //< Default Max Timout is 3s    
        start = new Date().getTime(),                                                             
        condition = false,                                                                        
        interval = setInterval(function() {                                                       
            if ( (new Date().getTime() - start < maxtimeOutMillis) && !condition ) {              
                // If not time-out yet and condition not yet fulfilled                            
                condition = (typeof(testFx) === "string" ? eval(testFx) : testFx()); //< defensive code                                                                                             
            } else {                                                                              
                if(!condition) {                                                                  
                    // If condition still not fulfilled (timeout but condition is 'false')        
                    console.log("'waitFor()' timeout");                                           
                    phantom.exit(1);                                                              
                } else {                                                                          
                    // Condition fulfilled (timeout and/or condition is 'true')                   
                    console.log("'waitFor()' finished in " + (new Date().getTime() - start) + "ms.");                                                                                               
                    typeof(onReady) === "string" ? eval(onReady) : onReady(); //< Do what it's supposed to do once the condition is fulfilled                                                       
                    clearInterval(interval); //< Stop this interval                               
                }                                                                                 
            }                                                                                     
        }, 100); //< repeat check every 250ms                                                     
};                                                                                                
if (phantom.args.length === 0 || phantom.args.length > 2) {                                       
  console.log('Usage: run-qunit.js URL');                                                       
  phantom.exit(1);                                                                              
}                                                                                                 
var page = require('webpage').create();                                                           
//
// 위에 설명했어요. ~
//
page.onConsoleMessage = function(msg) {                                                           
  console.log(msg);                                                                               
};                                                                                                
page.open(phantom.args[0], function(status){                                                      
  //
  // 성공여부 판단
  //
  if (status !== "success") {                                                                     
    console.log("Unable to access network");                                                      
    phantom.exit(1);                                                                              
  } else {
    //
    // waitFor 사용
    // 첫번째 textFunc
    //  -> qunit 테스트결과가 브라우져에 모두 표시되면 qunit 엘리먼트 안에 여러가지 엘리먼트가 생기는데
    // 그중 qunit-testresult 엘리먼트의 유무를 판단합니다.
    //                                                                                        
    waitFor(function(){                                                                           
      return page.evaluate(function(){                                                            
        var el = document.getElementById('qunit-testresult');                                     
        if (el && el.innerText.match('completed')) {                                              
          return true;                                                                            
        }                                                              
        return false;                                                  
      });                                                              
    },
    //
    // qunit-testresult 엘리먼트의 텍스트가 completed 값이 포함되어 있다는 것이 분석되면 실행됩니다.
    //
    function(){                                                     
      var failedNum = page.evaluate(function(){                        
        var el = document.getElementById('qunit-testresult');          
        console.log('=========================');                      
        console.log(el.innerText);                                     
        console.log('=========================');                      
        //
        // 실패 갯수를 리턴합니다.
        //         
        return el.getElementsByClassName('failed')[0].innerHTML;     
      });
      //
      // failedNum이 0이면 성공이요
      // 그렇지 않으면 에러번호를 출력하는 구문입니다.
      // bash errorcode 아시죠?
      //                                                              
      phantom.exit((parseInt(failedNum, 10) > 0) ? 1 : 0);             
    });                                                                
  }                                                                    
});    